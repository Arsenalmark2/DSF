
#include <iostream>
#include "binarytree.h"
#include "queueadt.h"

using namespace std;

binarytree::binarytree() {
	// TODO Auto-generated constructor stub
	root = 0;
}

Bnode* maketree(int x)
{
	Bnode *temp = new Bnode();
	temp->lchild = temp->rchild = 0;
	temp->data = x;
}

// Return address of root node
Bnode* binarytree::getrootnode()
{
	return root;
}

// iterative creation of tree
void binarytree::I_create_tree()
{
	queueadt q;
	cout<<"Enter  root value :- "; 
	Bnode *temp;
	int value;
	cin>>value;
	root = maketree(value);
	q.enqueue(root);
	while(!q.isempty())
	{
		temp = q.dequeue();		// dequeue first element from queue
		cout<<"Enter left child value of node of(-1 for no data) "<<temp->data<<" : ";
		cin>>value;
		//if value is -1 then no new node will be connnected to left child
		if(value != -1)
		{
			temp -> lchild = maketree(value);
			q.enqueue(temp->lchild);
		}
		cout<<"Enter right child value of node of(-1 for no data)"<<temp->data<<" : ";
		cin>>value;
		//if value is -1 then no new node will be connnected to right child
		if(value != -1)
		{
			temp -> rchild = maketree(value);
			q.enqueue(temp->rchild);
		}
	}
}

//to calulate longest path between root and nodes of tree 
int binarytree::depth(Bnode *temp)
{
	if (temp == 0)
    return 0;
  else 
    return 1 + max(depth(temp->lchild),depth(temp->rchild));
}

// Copying 1 tree to another
void binarytree::copy_tree(Bnode *tree2, Bnode *tree1)
{
    if(tree1== NULL)
         tree2 = NULL;
     else
	{
		tree2  = maketree(tree1->data);
		copy_tree(tree2->lchild,tree1->lchild);		// call copy_tree function recursive
													// with left child of tree2 and tree1
		copy_tree(tree2->rchild,tree1->rchild);		// call copy_tree function recursive 
													//with right child of tree2 and tree1
	}
}

// Recursive Insertion 
Bnode* binarytree::insert_r (Bnode *T )
{    // T root node
     if(T == 0)
	{
		T= new Bnode();
		cout<<"Enter node value : ";
		cin>>T->data;	// Create the Root node pointed by T
		T->lchild = T->rchild = 0; 
		return T;
	}
    else
    {
    	Bnode *Q=T;
		//where to insert  take choice from the user
		cout<<"Insertion at "<<Q->data<<" \n1. left child\n2.Right child"<<"Enter choice  :- ";
		int choice;
		cin>>choice;
		switch(choice)
		{
			case 1:
				Q->lchild=insert_r(Q->lchild);	//Insert at left
				break;
			case 2:
				Q->rchild=insert_r(Q->rchild);	//Insert at right
		}
	}
}
// end of insert recursivelly.  

//Iterative Insertion 
void binarytree::insert_i()
{
	Bnode *temp = root;
	int value = -1;
	int choice;
	if(root == 0)
	{
		cin>>value;
		root = maketree(value);
	}
	else
	{
		//continue loop till insertion is not done
		do{
			cout<<"Insertion at "<<temp->data<<" \n1. left child\n2.Right child"<<"Enter choice  :- ";
			cin>>choice;
			if(choice == 1)
			{
				if(temp->lchild == 0)
				{
					cout<<"Enter node value : ";
					cin>>value;
					temp->lchild = maketree(value);
				}
				else
					temp = temp->lchild;
			}
			else if(choice == 2)
			{
				if(temp->lchild == 0)
				{
					cout<<"Enter node value : ";
					cin>>value;
					temp->rchild = maketree(value);
				}
				else
					temp = temp->rchild;
			}
		}while(value == -1);
	}
}

void binarytree::preorder(Bnode *temp)
{
	if(temp != 0)
	{
		cout<<temp->data<<" ";		// visit root
		preorder(temp->lchild);		// go to left child
		preorder(temp->rchild);		// go to right child
	}
}

void binarytree::postorder(Bnode *temp)
{
	if(temp != 0)
	{	
		postorder(temp->lchild);	// go to left child
		postorder(temp->rchild);	// go to right child
		cout<<temp->data<<" ";		// visit root
	}
}
void binarytree::inorder(Bnode *temp)
{
	if(temp != 0)
	{
		inorder(temp->lchild);		// go to left child
		cout<<temp->data<<" ";		// visit root
		inorder(temp->rchild);		// go to right child
	}
}

// print leaf node of tree
void printleafnode(Bnode *root)
{
	//if node is null return
	if(root == 0)
		return;
	//if node is leaf node , print data
	if(root->lchild == 0 && root->rchild == 0)
	{
		cout<<root->data<<" ";
		return;
	}
	//if left child exist check for
	//leaf node recurssive
	if(root->lchild != 0)
		printleafnode(root->lchild);
	//if right child exist check for
	//leaf node recurssive
	if(root->rchild != 0)
		printleafnode(root->rchild);
}
void binarytree::display()
{
	if(root != NULL)
	{
		cout<<"Inorder Travesral  :-  ";
		inorder(root);
		cout<<"Preorder Traversal  :- ";
		preorder(root);
		cout<<"Postorder Traversal :- ";
		postorder(root);
	}
	else cout<<"Tree is empty ";
}

binarytree::~binarytree() {
	// TODO Auto-generated destructor stub
}
