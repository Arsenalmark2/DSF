  //============================================================================
// Name        : assignment3.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "binarytree.h"
using namespace std;

int main() {
	binarytree b;
	b.I_create_tree();
	b.insert_r(b.getrootnode());
	b.insert_i();
	b.display();
	return 0;
}
