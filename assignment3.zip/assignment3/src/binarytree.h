/*
 * binarytree.h
 *
 *  Created on: 09-Feb-2020
 *      Author: user
 */

#ifndef BINARYTREE_H_
#define BINARYTREE_H_

#include "queueadt.h"

class binarytree {
	Bnode *root;
public:
	binarytree();
	Bnode *getrootnode();
	Bnode* insert_r (Bnode *T );
	void insert_i();
	void preorder(Bnode *);
	void postorder(Bnode *);
	void inorder(Bnode *);
	void display();
	int depth(Bnode *);
	void copy_tree(Bnode *tree2, Bnode * tree1);
	void I_create_tree();
	virtual ~binarytree();
};

#endif /* BINARYTREE_H_ */
