/*
 * queueadt.h
 *
 *  Created on: 09-Feb-2020
 *      Author: user
 */

#ifndef QUEUEADT_H_
#define QUEUEADT_H_

struct Bnode
{
	int data;
	Bnode *lchild;
	Bnode *rchild;
};
struct queue_node{

	Bnode* data;
	struct queue_node *next;
};
class queueadt {
public:
	queue_node *front,*rear;
	queueadt();
	void enqueue(Bnode *);
	Bnode *dequeue();
	bool isempty();
	virtual ~queueadt();
};

#endif /* QUEUEADT_H_ */
