/*
 * queueadt.cpp
 *
 *  Created on: 09-Feb-2020
 *      Author: user
 */

#include "queueadt.h"

queueadt::queueadt() {
	front = 0;
	rear = 0;
	// TODO Auto-generated constructor stub

}

// if queue is empty
bool queueadt::isempty()
{
	if(rear == 0)
		return true;
	return false;
}


void queueadt::enqueue(Bnode* temp)
{

	if(isempty())	//if queue is empty
	{
		front = new queue_node();
		rear = front;
		rear->data = temp;
	}
	else
	{
		rear->next = new queue_node();
		rear = rear->next;
		rear->data = temp;
	}
}

Bnode *queueadt::dequeue()
{
	if(isempty())
		return 0;
	else
	{
		queue_node *temp = front;
		if(front == rear)
			front = rear = 0;
		else
		front = front->next;
		Bnode *t1 = temp->data;
		delete temp;
		return t1;
	}
}

queueadt::~queueadt() {
	// TODO Auto-generated destructor stub
}

