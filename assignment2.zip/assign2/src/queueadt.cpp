
#include <iostream>
#include "queueadt.h"
#include <string.h>
using namespace std;

queueadt::queueadt() {
	front = 0;
	rear = 0;
}

// function to check if there is special character present or not
bool check(string str)
{
	int i = 0,j = 0;
	while(str[i] != '\0')
	{
		if(isalpha(str[i]) || str[i] == ' ')
		{
			j++;
		}
		i++;
	}
	if(i == j)
		return true;
	else
		cout<<"\n\tOnly alphabets are allowed";
	return false;
}
patient queueadt::input()
{
	patient p;
	do
	{
		cout<<"\tEnter patient name : ";
		cin>>p.name;
	}while(!check(p.name));
	cout<<"\tEnter Reg. ID : ";
	cin>>p.regid;
	cout<<"\tEnter Height : ";
	cin>>p.height;
	cout<<"\tEnter bloodgroup : ";
	cin>>p.bloodgroup;
	cout<<"\tEnter blood pressure : ";
	cin>>p.bp;
	strcat(p.bp,"mm");
	return p;
}


void queueadt::next_patient()
{
	if(front == NULL)
		cout<<"\n\t No patients are remaining";
	else
	{
		cout<<"\n\t------------------------------------------";
		cout<<"\n\tRegistration ID :- "<<front->data.regid;
		cout<<"\n\tName :- "<<front->data.name;
		cout<<"\n\tBloodgroup:- "<<front->data.bloodgroup;
		cout<<"\n\tBlood Pressure :- "<<front->data.bp;
		cout<<"\n\tHeight :- "<<front->data.height;
		cout<<"\n\tCondition of patient :- ";
		if(front->priority == 3)
			cout<<"Serious";
		else if(front->priority == 2)
			cout<<"Medium";
		else
			cout<<"Normal";
		cout<<"\n\t------------------------------------------";
	}
}
void queueadt::admitting_patient()
{
	node *new_node = new node();
	new_node->data = input();
	cout<<"\tCondition of patient \n\t1.Normal \n\t2. Medium \n\t3. Serious ";
	cout<<"\n\tEnter :- ";
	cin>>new_node->priority;
	if(front == 0 && rear == 0)
	{
		rear = new_node;
		front = new_node;
	}
	else
	{
		node *temp = front;
		if(temp->priority < new_node->priority)
		{
			new_node->next = front;
			front = new_node;
		}
		else
		{
			node *prev =0;
			while(temp != 0 && temp->priority > new_node->priority)
			{
				prev = temp;
				temp = temp->next;
			}
			if(temp == 0)
				rear = new_node;
			prev->next = new_node;
			new_node->next = temp;
		}
	}
}

void queueadt::serve_first()
{
	node *temp = front;
	if(!isempty())
	{
		if(front == rear)
			front = rear = 0;
		else
			front = front->next;
		cout<<"\n\t"<<temp->data.name<<" is treated";
		delete temp;
	}
}
void queueadt::display()
{

	if(isempty())
		cout<<"\n\tAll patients have been treated";
	else
	{
		cout<<"\n\tList of Patient :- ";
		node *temp = front;
		int i = 1;
		while(temp != NULL)
		{
			cout<<"\n\t------------------------------------------";
			cout<<"\n\tPatient No. :- "<<i;
			cout<<"\n\tRegistration ID :- "<<temp->data.regid;
			cout<<"\n\tName :- "<<temp->data.name;
			cout<<"\n\tBloodgroup:- "<<temp->data.bloodgroup;
			cout<<"\n\tBlood Pressure :- "<<temp->data.bp;
			cout<<"\n\tHeight :- "<<temp->data.height;
			cout<<"\n\tCondition of patient :- ";
			if(temp->priority == 3)
				cout<<"Serious";
			else if(temp->priority == 2)
				cout<<"Medium";
			else
				cout<<"General";
			temp = temp->next;
			i++;
		}
	}

}
bool queueadt::isempty()
{
	if(front == 0)
		return true;
	return false;
}

queueadt::~queueadt() {
	// TODO Auto-generated destructor stub
}

