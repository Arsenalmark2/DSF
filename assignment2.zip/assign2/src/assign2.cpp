//============================================================================
// Name        : assign2.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "queueadt.h"
using namespace std;

int main() {
	queueadt s;
	int choice;
	while(1)
	{
		cout<<"\n\t------------------------------------------";
		cout<<endl<<"\t***Welcome To the Hospital***";
		cout<<"\n\t------------------------------------------";
		cout<<"\n\t1. Admit a patient ";
		cout<<"\n\t2. Serving patient";
		cout<<"\n\t3. Next patient";
		cout<<"\n\t4. List of patients to be treated";
		cout<<"\n\t5. Exit";
		cout<<"\n\tEnter your choice :- ";
		cin>>choice;
		cout<<endl;
		switch(choice)
		{
			case 1:
				s.admitting_patient();
				break;
			case 2:
				s.next_patient();
				s.serve_first();
				break;
			case 3:
				s.next_patient();
				break;
			case 4:
				s.display();
				break;
			case 5:
				cout<<"\n\tTake care Bye";
				return 0;
		}
	}
	return 0;
}
