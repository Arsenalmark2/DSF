/*
 * queueadt.h
 *
 *  Created on: 16-Jan-2020
 *      Author: user
 */

#ifndef QUEUEADT_H_
#define QUEUEADT_H_

struct patient
{
	int regid;
	char name[20];
	int height;
	char bp[6];
	char bloodgroup[6];
};

struct node
{
	patient data;
	int priority;
	struct node *next;
};

class queueadt {

private :
		node *front;
		node *rear;
public:
		queueadt();
		bool isempty();
		void display();
		void next_patient();
		patient input();
		void admitting_patient();
		void serve_first();
		virtual ~queueadt();
};

#endif /* QUEUEADT_H_ */
