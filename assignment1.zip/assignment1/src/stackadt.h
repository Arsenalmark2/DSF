

#include"listadt.h"

#ifndef STACKADT_H_
#define STACKADT_H_

template<class T>
class stackadt
{
	private:
		listadt<T> li;
	public:
		stackadt();
		void push(T);
		T pop();
		void display();
		bool empty();
		T peep();
		virtual ~stackadt();
};

#endif /* STACKADT_H_ */
