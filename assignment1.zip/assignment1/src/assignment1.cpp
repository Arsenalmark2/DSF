

#include <iostream>
#include <algorithm>
#include <math.h>
#include <string.h>
#include "stackadt.h"
#include "stackadt.cpp"
using namespace std;

class expression
{
	char infix[40],postfix[40],prefix[40];
	public :
		void input();
		void output(int);
		void InfixtoPostfix();
		void InfixtoPrefix();
		float postevalexp(int);
		float preevalexp();
		bool opt(char);
		int numoperator();
		int precendence(char);
		bool associativity(char);
};
// to take input
void expression :: input()
{
	cout<<" Enter Expression : ";
	cin>>infix;
}
//function returns the number of operator
int expression::numoperator()
{
	int i = 0, j = 0;
	while(postfix[i] != '\0')
	{
		if(isalpha(postfix[i]))
			j++;
		i++;
	}
	return j;
}
//display output 
void expression::output(int i)
{
	cout<<endl<<"Infix expression : "<<infix<<endl;
	if(i == 1)
		cout<<"postfix expression : "<<postfix<<endl;
	else
		cout<<"prefix expression : "<<prefix<<endl;
}


bool expression::associativity(char a)
{
	//right to left associativity
	if(a == '^')
		return false;
	//LR associativity
	else return true;
}
// to check char is operator
bool expression::opt(char a)
{
	if(a == '+' || a == '-' || a == '*' || a == '/')
		return true;
	if(a == '^' || a == '(' || a == ')')
		return true;
	return false;
}
//function returns precendences of operator
int expression :: precendence(char a)
{
	switch (a)
	{
		case '+' :
				return 2;
		case '-' :
				return 2;
		case '/' :
				return 4;
		case '*' :
				return 4;
		case '^' :
				return 6;
		default :
				return 0;
	}
}
// function convert infix to postfix
void expression :: InfixtoPostfix()
{
	stackadt<char> s;
	int i = 0;
	int j = 0;
	char ch;
	memset(postfix,0,strlen(postfix));
	cout<<"\t"<<"Infix \t"<<"Stack \t"<<"expression"<<endl;
	while(infix[i] != '\0')
	{
		//If infix[i] is not operator
		if(!opt(infix[i]))
		{
			postfix[j] = infix[i];
			j++;
		}
		else
		{
			//if stack is empty or precendence of top element of stack is less than that of infix[i]
			if(s.empty()||infix[i] == '(' ||precendence(s.peep())<precendence(infix[i]))
				s.push(infix[i]);
			//if ')' occurs then pop all elements
			else if(infix[i] == ')')
			{
				if(s.peep() == '(')
					s.pop();
				while(!s.empty() && s.peep() != '(')
				{
					ch = s.pop();
					postfix[j] = ch;
					j++;
				}
				if(s.peep() == '(')
					s.pop();
			}
		//if precedence is same then check associativity
		else if(precendence(s.peep())==precendence(infix[i]))
		{
			if(this->associativity(infix[i]))
			{
				postfix[j] = s.pop();
				j++;
				s.push(infix[i]);
			}
			else s.push(infix[i]);
		}
		else
		{
			//pop element untill precendence of top is greater than or equal to that of infix[i]
			while(!s.empty()&&precendence(s.peep())>=precendence(infix[i]) )
			{
				postfix[j] = s.pop();
				j++;
			}
			s.push(infix[i]);
		}
		}
		cout<<"\t"<<infix[i]<<"\t";
		s.display();
		cout<<"\t"<<postfix<<endl;
		i++;

	}
	cout<<"\t"<<"empty"<<"\t";
	//if operators are remaining in stack
	while(!s.empty())
	{
		ch = s.pop();
		if(ch != '(')
		{
			postfix[j] = ch;
			j++;
		}
	}
	postfix[j] = '\0';
	s.display();
	cout<<"\t"<<postfix<<endl;
}

//Evaluate prefix expression and returns result
float expression::postevalexp(int k = 0)
{
	stackadt<float> s;
	int i = 0;
	float a,b;
	int n = numoperator();
	int j = 0;
	float arr[n];
	cout<<" Enter values of operands\n";
	while(postfix[i] != '\0')
	{
		//if postfix[i] is operand
		if(isalpha(postfix[i]))
		{
			cout<<" Enter value for "<<postfix[i]<<" :- ";
			cin>>arr[j++];
		}
		i++;
	}
	i = 0;
	j = 0;
	cout<<"\t"<<"Expression"<<"\t"<<"Stack";
	while(postfix[i] != '\0')
	{
		//if postfix[i] is operand then push the value of that operand
		if(!opt(postfix[i]))
		{
			s.push(arr[j++]);
		}
		else
		{
		 	b = s.pop();
			a = s.pop();
			switch(postfix[i])
			{
				case '+' :
					s.push(a+b);
					break;
				case '-' :
					if(k == 1)
					s.push(b-a);
					else
					s.push(a-b);
					break;
				case '*' :
					s.push(a*b);
					break;
				case '/' :
					if(k == 1)
					s.push(b/a);
					else
					s.push(a/b);
					break;
				case '^' :
					if(k == 1)
					s.push(pow(b,a));
					else
					s.push(pow(a,b));
					break;
			}
		}
		cout<<"\t"<<postfix[i]<<"\t";
		if(!s.empty())
		s.display();
		cout<<endl;
		i++;
	}
	cout<<"\t"<<"empty\t";
	cout<<s.peep();
	//returns evaluated value
	return s.peep();
}
//reverse the string
void reverse_str(char *p)
{
	int len = strlen(p);
	char ch;
	int i=0;
	for (i = 0; i < len/2 ; ++i)
	{
		ch = p[i];
		p[i] = p[len-i-1];
		p[len-i-1] = ch;
	}
}
//Infix to prefix conversion
void expression::InfixtoPrefix()
{
	reverse_str(infix);
	int i = 0;
	while( infix[i] != '\0' )
	{
		if(infix[i] == ')')
			infix[i] = '(';
		else if(infix[i] == '(')
			infix[i] = ')';
		i++;
	}
	InfixtoPostfix();
	strcpy(prefix,postfix);
	reverse_str(prefix);
}
//Evaluate prefix expression and returns result
float expression::preevalexp()
{
	reverse_str(prefix);
	strcpy(postfix,prefix);
	return postevalexp(1);

}

int main()
{
	int a;
	float b;
	expression e;
	while(1)
	{
		cout<<"\n\n----------Expression Evaluation and Conversion using Stack----------\n"<<endl;
		cout<<"\n 1. Input ";
		cout<<"\n 2. Infix to Postfix conversion ";
		cout<<"\n 3. Evaluation by Postfix ";
		cout<<"\n 4. Infix to Prefix conversion";
		cout<<"\n 5. Evaluation by Prefix ";
		cout<<"\n 6. Exit"<<endl;
		cout << " Enter choice :- ";
		cin>>a;
		switch(a)
		{
			case 1 :
				cin.ignore();
				e.input();
				break;
			case 2 :
				e.InfixtoPostfix();
				e.output(1);
				break;
			case 3 :
				b = e.postevalexp();
				cout<<" \nCalculated value of expression is :- "<<b;
				break;
			case 4 :
				e.InfixtoPrefix();
				e.output(2);
				break;
			case 5 :
				b = e.preevalexp();
				cout<<" \nCalculated value of expression is :- "<<b;
				break;
			case 6 :
				cout<<" Exited !!!"<<endl;
				return 0;
		}
	}
}
