/*
 * listadt.h
 *
 *  Created on: 18-Dec-2019
 *      Author: g9
 */

#ifndef LISTADT_H_
#define LISTADT_H_

template<typename T>
struct node
{
	T data;
	struct node<T> *next;
};

template<class T>
class listadt
{
	private :
		node<T> *head;
	public	:
		listadt();
		bool empty();
		T value();
		void display();
		void display1(node<T> *);
		void ins_front(T);
		T del_front();
		virtual ~listadt();
};

#endif /* LISTADT_H_ */
