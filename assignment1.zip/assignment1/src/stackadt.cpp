/*
 * stackadt.cpp
 *
 *  Created on: 18-Dec-2019
 *      Author: g9
 */

#include "stackadt.h"
#include "listadt.cpp"

template<typename T>
stackadt<T>::stackadt() {
	// TODO Auto-generated constructor stub

}

template<class T>
void stackadt<T>::push(T x)
{
	li.ins_front(x);
}

template<class T>
void stackadt<T>::display()
{
	li.display();
}

template<class T>
T stackadt<T>::peep()
{
	return li.value();
}

template<class T>
T stackadt<T>::pop()
{
	return li.del_front();
}

template<class T>
bool stackadt<T>::empty()
{
	return li.empty();
}

template<class T>
stackadt<T>::~stackadt() {
	// TODO Auto-generated destructor stub
}

