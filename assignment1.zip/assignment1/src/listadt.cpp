
#include<iostream>
#include "listadt.h"
using namespace std;

template<typename T>
listadt<T>::listadt() {
	head = 0;
}

template<class T>
void listadt<T>::display()
{
	node<T> *temp = head;
	if(head == NULL)
	{
		cout<<"empty";
	}
	while(temp != 0)
	{
		cout<<temp->data<<",";
		temp = temp->next;
	}
}

template<class T>
void listadt<T>::ins_front(T x)
{
	node<T> *temp = new node<T>();
	temp->data = x;
	temp->next = head;
	head = temp;
}

template<class T>
T listadt<T>::value()
{
	return head->data;
}

template<class T>
T listadt<T>::del_front()
{
	node<T> *temp = head;
	head = head->next;
	T data = temp->data;
	delete temp;
	return data;
}

template<class T>
bool listadt<T>::empty()
{
	if(head == 0)
		return true;
	return false;
}

template<class T>
listadt<T>::~listadt() {
	// TODO Auto-generated destructor stub
}

