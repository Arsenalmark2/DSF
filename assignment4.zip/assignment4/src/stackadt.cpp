
#include "stackadt.h"

stackadt::stackadt() {
	top = 0;
	// TODO Auto-generated constructor stub
}
// check if stack is empty or not
//return true if stack is empty
bool stackadt::isempty()
{
	if(top == 0)
		return true;
	return false;
}
void stackadt::push(Bnode *node)
{
	stack_node *temp = new stack_node();
	temp->next = top;
	temp->data = node;
	top = temp;
}

Bnode* stackadt::peep()
{
	if(!isempty())
		{
			Bnode *node = top->data;
			return node;
		}
	else return 0;
}
Bnode * stackadt::pop()
{
	if(!isempty())
	{
		Bnode *node = top->data;
		stack_node *temp = top;
		top = top->next;
		//delete temp;
		return node;
	}
	else return 0;
}
stackadt::~stackadt() {
	// TODO Auto-generated destructor stub
}

