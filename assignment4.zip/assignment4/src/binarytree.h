/*
 * binarytree.h
 *
 *  Created on: 07-Feb-2020
 *      Author: user
 */

#ifndef BINARYTREE_H_
#define BINARYTREE_H_
#include "stackadt.h"

class binarytree {
	Bnode *root;
public:
	binarytree();
	void create_tree(char *str);
	Bnode *rootnode();
	void r_inorder(Bnode *);
	void r_preorder(Bnode *);
	void r_postorder(Bnode *);
	void nr_inorder();
	void nr_preorder();
	void nr_postorder();
	virtual ~binarytree();
};

#endif /* BINARYTREE_H_ */
