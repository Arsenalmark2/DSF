 b//============================================================================
// Name        : assignment3.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "binarytree.h"
using namespace std;

int main() {

		char postfix[] = "x+y+c";
		binarytree b;
		int choice;
		while(1)
		{
			cout<<"\n\t------------------------";
			cout<<"\n\t    Expression Tree  ";
			cout<<"\n\t------------------------";
			cout<<"\n\t1. Create Expression Tree";
			cout<<"\n\t2. Traversal of Expression Tree";
			cout<<"\n\t3.Exit";
			cout<<"\n\tEnter choice :- ";
			cin>>choice;
			switch(choice)
			{
				case 1:
					cout<<endl<<"\t Enter Postfix expression :- ";
					cin>>postfix;
					b.create_tree(postfix);
					cout<<"\n\t Tree created successfully";
					break;
				case 2:
					cout<<"\n\t Recursive Preorder Traversal  : ";
					b.r_preorder(b.rootnode());
					cout<<"\n\t Recursive Inorder  Traversal  : ";
					b.r_inorder(b.rootnode());
					cout<<"\n\t Recursive Postorder Traversal : ";
					b.r_postorder(b.rootnode());
					cout<<endl;
					cout<<"\n\t Iterative Preorder Traversal  : ";
					b.nr_preorder();
					cout<<"\n\t Iterative Inorder  Traversal  : ";
					b.nr_inorder();
					cout<<"\n\t Iterative Postorder Traversal : ";
					b.nr_postorder();
					break;
				case 3:
					cout<<"\n\t Exited!!!";
					return 0;
			}

		}


}
