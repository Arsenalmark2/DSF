
#include <iostream>
using namespace std;

#include "binarytree.h"


binarytree::binarytree() {
	// TODO Auto-generated constructor stub
	root = 0;
}
Bnode *binarytree:: rootnode()
{
	return root;
}

// if character is operator then return true else false
bool opt(char a)
{
	if(a == '+' || a == '-' || a == '*' || a == '/' || a == '^' )
		return true;
	return false;
}

// input is postfix expression
void binarytree::create_tree(char *str)
{
	int i = 0;
	Bnode *temp;
	stackadt s;
	while(str[i] != '\0')
	{
		if(isalpha(str[i])) //True if character is alphabet
		{
			temp = new Bnode();
			temp->left = 0;
			temp->right = 0;
			temp->data = str[i];
			s.push(temp);
		}
		else
		{
			if(opt(str[i]))
			{
				temp = new Bnode();
				temp->data = str[i];
				temp->right = s.pop();
				temp->left = s.pop();
				s.push(temp);
			}
		}
		i++;
	}
	root = s.pop();
}
// Recursive inorder traversal of tree
void binarytree::r_inorder(Bnode *temp)
{
	if(temp != 0)
	{
		r_inorder(temp->left);
		cout<<temp->data;
		r_inorder(temp->right);
	}
}

// non recursive traversal
void binarytree::nr_inorder()
{
	Bnode *temp = root;
		stackadt s;
		while(temp != 0 || !s.isempty())
		{
			if(temp != 0)
			{
				s.push(temp);
				temp = temp->left;	//left child
			}
			else
			{
				temp = s.pop();
				cout<<temp->data;   // root
				temp = temp->right;	//right child
			}
		}
}

// Recursive preorder
void binarytree::r_preorder(Bnode *temp)
{
	if(temp != 0)
	{
		cout<<temp->data;
		r_preorder(temp->left);
		r_preorder(temp->right);
	}
}

void binarytree::nr_preorder()
{
	Bnode *temp = root;
	stackadt s;
	while(temp != 0 || !s.isempty())
	{
		if(temp != 0)
		{
			cout<<temp->data;   // root
			s.push(temp);
			temp = temp->left;	//left child
		}
		else
		{
			temp = s.pop();
			temp = temp->right;	//right child
		}
	}
}
// Recursive postorder
void binarytree::r_postorder(Bnode *temp)
{
	if(temp != 0)
	{
		r_postorder(temp->left);
		r_postorder(temp->right);
		cout<<temp->data;
	}
}
//Non recursive of post order
void binarytree::nr_postorder()
{
	stackadt s1,s2;
	s1.push(root);
	Bnode *temp ;
	while(!s1.isempty())
	{
		temp = s1.pop();
		s2.push(temp);
		if(temp -> left != 0)
			s1.push(temp->left);
		if(temp -> right != 0)
			s1.push(temp -> right);
	}
	while(!s2.isempty())
	{
		cout<<s2.pop()->data;
	}
}


binarytree::~binarytree() {
	// TODO Auto-generated destructor stub
}


