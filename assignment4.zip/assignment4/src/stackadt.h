/*
 * stackadt.h
 *
 *  Created on: 07-Feb-2020
 *      Author: user
 */

#ifndef STACKADT_H_
#define STACKADT_H_

struct Bnode
{
	char data;
	Bnode *left;
	Bnode *right;
};
struct stack_node{

	Bnode* data;
	struct stack_node *next;
};

class stackadt {
	stack_node *top;
	public:
		stackadt();
		void push(Bnode *);
		Bnode* pop();
		Bnode* peep();
		bool isempty();
		virtual ~stackadt();
};

#endif /* STACKADT_H_ */
